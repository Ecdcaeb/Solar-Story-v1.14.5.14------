#include <windows.h>
HINSTANCE this_windows;
class Button{
	public:
		bool isEmpty=true;
		int stx;//��ʼx 
		int sty;//��ʼy 
		int _x;//x 
		int _y;//y 
		LPCSTR path;//bmp·�� δѡ�� 
//		LPCWSTR road2;//��ѡ��
//		LPCWSTR road3;//�Ѱ��� 
		bool isDown=0; 
		bool *show;
		//���� 
		set(int x,int y,int x_,int y_,LPCSTR str,bool *show_){
			stx=x;
			sty=y;
			_x=x_;
			_y=y_;
			path=str;
			isEmpty=false;
			show=show_;
		}
		in(int x,int y){
			if(x>=stx && x<=(stx+_x) && y>=sty && y<=(sty+_y))return true;
			else false;
		}
	
}; 
Button newButton(int x,int y,int x_,int y_,LPCSTR str,bool *show_){
	Button button;
	button.set(x, y, x_,y_,str,show_);
	return button;
}
void  paint_button(HWND hwnd,HDC hdc,Button button){//����һ��ͼƬ��ʵ�� 
	//����ͼƬ 
	if(*(button.show)==true){
		HBITMAP bitmap=(HBITMAP)(LoadImageA(this_windows,button.path,IMAGE_BITMAP,0,0,0x0010));
	//����ͼƬ 
	//����DC
	HDC ohdc=CreateCompatibleDC(hdc);
	SelectObject(ohdc,bitmap);
	//��ͼ
	BitBlt(hdc,button.stx,button.sty,
	(button._x),//ͼƬ���� 
	(button._y),//ͼƬ�߶� 
	ohdc,0,0,SRCCOPY);
	}
}
bool canshow=true;
Button button1=newButton(10,10,10,10,"button.bmp",&canshow);
//class Buttons{
//	private:
//		Button Empty=Button();
//		Button button[]=new Button();
//		int long_=0;
//	public:
//		void register_(Button botton_){
//			button[long_]=botton_;
//			long_++;
//		}
//		Button get(int index){
//			if(index<=long_){
//				return button[index];
//			}
//			else return Empty;
//		}
//		void Paint_Button(HWND hwnd,HDC hdc,HBITMAP background){
//			//����ͼƬ 
//			//����DC
//			HDC ohdc=CreateCompatibleDC(hdc);
//			SelectObject(ohdc,background);
//			//��ͼ
//			for(int i=0;i<=long_;i++){
//				if(!button[i].isEmpty){
//					paint_button(hwnd,ohdc,button[i]);
//				}
//			}
//			//�ϲ� 
//			BitBlt(hdc,0,0,
//			(640),//ͼƬ���� 
//			(480),//ͼƬ�߶� 
//			ohdc,0,0,SRCCOPY);
//		}
//};
//Buttons main;
void  Paint_background(HWND hwnd,HDC hdc,LPCSTR str){
	
	HBITMAP bitmap=(HBITMAP)(LoadImageA(this_windows,str,IMAGE_BITMAP,0,0,0x0010));
	HDC ohdc=CreateCompatibleDC(hdc);
	SelectObject(ohdc,bitmap);
	
	BitBlt(hdc,0,0,
	640,
	480,
	ohdc,0,0,SRCCOPY);
}
void Windows_paint(HDC hdc,HWND hwnd){
	//���μ���
	//��ȡ�ͻ��˴�С 
	RECT rt;
	GetClientRect(hwnd,&rt);
	int WC_width=rt.right-rt.left; 
	int WC_higth=rt.bottom-rt.top;
	//����λͼ 
	HBITMAP background=CreateCompatibleBitmap(hdc,WC_width,WC_higth);
	//��������DC
	HDC ohdc=CreateCompatibleDC(hdc);
	SelectObject(ohdc,background);
	//������Ʒ
	Paint_background(hwnd,ohdc,"1.bmp");
	TextOut(ohdc,0,0,"����һ�����֣�",12);
	paint_button(hwnd,ohdc,button1);
	//�ϲ� 
	BitBlt(hdc,0,0,WC_width,WC_higth,ohdc,0,0,SRCCOPY);
} 
/* This is where all the input to the window goes to */
LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;//����
	HDC hdc;//��ͼ���
	switch(Message) {
		case WM_PAINT:{
			//��ʼ��ͼ
			hdc=BeginPaint(hwnd,&ps);
			//��ͼ
			Windows_paint(hdc,hwnd);
			//������ͼ 
			EndPaint(hwnd,&ps);
			break;
		}
		
		/* Upon destruction, tell the main thread to stop */
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		case WM_COMMAND:{
			switch(LOWORD(wParam)) {
				case 1002:{
					MessageBox(hwnd,"helloworld","1002",NULL);
					break;
				} 
				case 1004:
					canshow=!canshow;
					InvalidateRect(hwnd,NULL,TRUE);
					break;
			}
			break;
		}
		case WM_LBUTTONDOWN:{//���������ʱ 
			//��ȡ������� 
			int cx=LOWORD(lParam);
			int cy=HIWORD(lParam);
			//dialog�ƽ� 
			if(*(button1.show)==true){
				if(button1.in(cx,cy)){
					canshow=!canshow;
				}
			}
			
			InvalidateRect(hwnd,NULL,TRUE);//���� 
			break;
		} 
//		case WM_CLOSE:{
//			MessageBox(hwnd,"helloworld","helloworld",NULL);
//			break;
//		}
		
		/* All other messages (a lot of them) are processed using default procedures */
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}

/* The 'main' function of Win32 GUI programs: this is where execution starts */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	WNDCLASSEX wc; /* A properties struct of our window */
	HWND hwnd; /* A 'HANDLE', hence the H, or a pointer to our window */
	MSG msg; /* A temporary location for all messages */

	/* zero out the struct and set the stuff we want to modify */
	memset(&wc,0,sizeof(wc));
	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.lpfnWndProc	 = WndProc; /* This is where we will send messages to */
	wc.hInstance	 = hInstance;
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	
	/* White, COLOR_WINDOW is just a #define for a system color, try Ctrl+Clicking it */
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszMenuName  = "MAINMENU";
	wc.lpszClassName = "WindowClass";
	wc.hIcon		 = LoadIcon(NULL, IDI_APPLICATION); /* Load a standard icon */
	wc.hIconSm		 = LoadIcon(NULL, IDI_APPLICATION); /* use the name "A" to use the project icon */

	if(!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","Caption",WS_VISIBLE|WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, /* x */
		CW_USEDEFAULT, /* y */
		640, /* width */
		480, /* height */
		NULL,NULL,hInstance,NULL);

	if(hwnd == NULL) {
		MessageBox(NULL, "Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK);
		return 0;
	}
	this_windows= hInstance;

	/*
		This is the heart of our program where all input is processed and 
		sent to WndProc. Note that GetMessage blocks code flow until it receives something, so
		this loop will not produce unreasonably high CPU usage
	*/
	while(GetMessage(&msg, NULL, 0, 0) > 0) { /* If no error is received... */
		TranslateMessage(&msg); /* Translate key codes to chars if present */
		DispatchMessage(&msg); /* Send it to WndProc */
	}
	return msg.wParam;
}
